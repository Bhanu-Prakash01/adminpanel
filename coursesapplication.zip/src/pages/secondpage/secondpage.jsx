import './secondpage.css';
import Verybottom from '../../components/verybottom/verybottom';
import Submit from '../../components/submit/submit';
import Faq from '../../components/faq/faq';
import Footer from '../../components/footer/footer';
import Learnerviewbox from '../../components/learnereview/learneriviewbox'
import Technologyexpert from '../../components/technologyexperts/technologyexpert';
import Programoverview from '../../components/programoverview/programoverview';
function Secondpage(){
    return(
        <>
        <div className="submit">
        <div className="su">
            <Submit/></div>
        </div>
        <div className="program">
            <h1 style={{color:'black',marginTop:10}}>Program Overview</h1>
            <Programoverview/>
        </div>
        <div  className="learnfromtechnologyexperts">
            <h1 style={{color:'blue',marginTop:10}}>Learn From Technology Experts</h1>
            <Technologyexpert/>
        </div>
        <div className="learner_review">
            <h1 style={{color:'white',marginTop:10}}>Learner review</h1>
            <div className="lr">
                <Learnerviewbox/>
                <Learnerviewbox/>
                <Learnerviewbox/>
                <Learnerviewbox/>
            </div>
        </div>
        <div className="faq">
        <h1 style={{color:'white',marginTop:10}}>FAQ</h1>
            <div className="f">
                <Faq/>
                <Faq/>
                <Faq/>
                <Faq/>
                <Faq/>
                <Faq/>
            </div>
        </div>
        <Footer/>
        <Verybottom/>
        </>
    )
}
export default Secondpage