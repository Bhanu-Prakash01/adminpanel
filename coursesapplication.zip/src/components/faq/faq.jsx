import './faq.css'
import React,{useState} from 'react';
function Faq(){
    const [ans,setAns]=useState(false)
    return(
        <>
        <div className="faq-box">
            <div className="faq-question-box" onClick={()=>setAns(!ans)}>
                <p className="faq-question">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Provident, magnam.</p>
                {ans? <i class="fas fa-chevron-up faq-arrow"></i>:<i class="fas fa-chevron-down faq-arrow"></i>}
            </div>
            {ans &&<div className="faq-answer-box">
                <p className="faq-answer">Lorem ipsum dolor sit amet consectetur adipisicing elit.  amet excepturi, consequatur velit, neque dolore minus a, eaque aliquid maxime et. Possimus ea rem accusamus nihil! Dolorum, maiores? Voluptas voluptatem iusto in impedit nihil ut facere?</p>
            </div>}
        </div>
        </>
    )
}
export default Faq;