import './navbar.css';
import React,{useState,useEffect} from 'react';
function List(){
    return(
        <ul className="nav-ul">
            <li className="nav-li">COURSES</li>
            <li className="nav-li">FAQ</li>
            <li className="nav-li">CONTACT US</li>
        </ul>
    )
}
function Mobilelist(){
    return(
        <>
        <ul className='mnav-ul'>
            <li className='mnav-li'>jnl</li>
            <li className='mnav-li'>jnl</li>
            <li className='mnav-li'>jnl</li>
        </ul>
        </>
    )
}
function Mobile(){
    const [active,setActive]=useState(false);
    return(
        <>
            {active && <Mobilelist/>}
            <span className="mobile" onClick={()=>setActive(!active)}><i class="fas fa-bars"></i></span>
            
        </>
    )
}
function Navbar(){
    const [ismobile,setIsMobile]=useState(window.matchMedia('(max-width:480px)').matches)
    useEffect(()=>{
        window.addEventListener('resize',()=>{
            setIsMobile(window.matchMedia('(max-width:480px)').matches)
        })
    })
   
    return(
        <>
        <div className="nav-box">
            <span className="nav-logo">LOGO</span>
            {ismobile?<Mobile/>:<List/>}
        </div>
        </>
    )
}
export default Navbar;