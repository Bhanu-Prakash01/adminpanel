import './learnerviewbox.css';
function Learnerviewbox(){
    return(
        <>
        <div className="learnerbox">
            <div className="learnertop">
                <img src="https://www.xebiaacademyglobal.com/careerpro_style/assets/images/ai/RAJNI.png" className="learnerimg" />
                <div className="learnerdetials">
                    <span className="learnername">DISHA</span>
                    <span className="learnercompany">Deloitte</span>
                    <span className="learneratting"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></span>
                </div>
            </div>
            <div className="learnerbottom">
                <p className="learnertext">Log elit. A sed b natus aperiam mollitia. Libero labore accusantium sunt perferendis eveniet, aliquid molestiae, exercitationem sequi, quo iusto ipsam!</p>
            </div>
        </div>
        </>

    )
}
export default Learnerviewbox;