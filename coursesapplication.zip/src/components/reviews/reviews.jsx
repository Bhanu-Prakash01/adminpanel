import './reviews.css';
import Aos from 'aos';
import React,{useEffect} from 'react';
import 'aos/dist/aos.css';
function Reviews(){
    var animations = ["fade-left","fade-right"];
    var animation = animations[Math.floor(Math.random() * animations.length)];
    useEffect(()=>{
        Aos.init({duration:2000});
    })
    return(
        <>
        <div className="review-box" data-aos={animation}>
            <div className="review-identity" >
                <p className="reviewername">Sunny</p>
                <span className="review-rating"><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i></span>
            </div>
            <div className="review-text-box"><p className="review-text">Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolore corporis omnis facere ut magnam saepe architecto minus in tempora ratione, ipsum pariatur, nesciunt non ullam adipisci voluptas rem tempore rerum!</p></div>
        </div>
        </>
    )
}
export default Reviews;