
export default function Newcity() {
    return (
      <div className="newProduct">
        <h1 className="addProductTitle">New Admin</h1>
        <form className="addProductForm">
          <div className="addProductItem">
            <label>Image</label>
            <input type="file" id="file" />
          </div>
          <div className="addProductItem">
            <label>Admin Name</label>
            <input type="text" placeholder="Admin Name" />
          </div>
          <div className="addProductItem">
            <label>Email</label>
            <input type="text" placeholder="Email" />
          </div>
          <div className="addProductItem">
            <label>Phone Number</label>
            <input type="text" placeholder="Phone Number" />
          </div>
          <div className="addProductItem">
            <label>Active</label>
            <select name="active" id="active">
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
          </div>
          <button className="addProductButton">Create</button>
        </form>
      </div>
    );
  }
  