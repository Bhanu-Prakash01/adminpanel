import './sendmail.css'
function Sendmail(){
    return(
        <div className='sendmailbody' style={{backgroundColor:'aliceblue'}}>
            <form className='mailbox'style={{backgroundColor:'white'}}>
                <label className='mwstitle'> Send Mail</label>
                <label className='sub'>Subject</label>
                <input type='text' className='mailsub' placeholder='Subject'></input>
                <textarea className='mailarea' placeholder='Body......'></textarea>
                <button className='mailsubmit' >Send</button>
            </form>
        </div>
    )
}
export default Sendmail;