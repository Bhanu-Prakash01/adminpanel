import './notify.css';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
function Notification(){
    return(
        <div className='noti'>
            <form className='box'>
                <label className='mwstitle'>Notification</label>
                <input type='text' className='nottittle' placeholder='Tittle...'/>
                <textarea className='areatext' placeholder='Type Message Here..'/>
                <button className='submit' onClick={() => toast("Wow so easy!")}>Submit</button>
            </form>
        </div>
    );
}
export default Notification;