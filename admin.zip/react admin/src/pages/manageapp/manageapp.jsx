import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
function Admin(){
    return(
        <div className='pop'>
            <form className='popbox'>
                <label className='mwstitle'> Manage App</label>
                <label className='mpop'>Status</label>
                <select name="active" className='labelbox'>
                    <option value="open">Open</option>
                    <option value="Close">Close</option>
                </select>
                <textarea className='areatext' placeholder='Type Message Here..'/>
                <button className='submit' onClick={() => toast("success!!!!")}>Submit</button>
            </form>
        </div>
    );
}
export default Admin;