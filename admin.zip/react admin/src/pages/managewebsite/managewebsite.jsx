import './managewebsite.css'
function Managewebsite(){
    return(
        <div className='mwbody'>
            <form className="formmw">
                <label className='mwstitle'> Manage Website</label>
                <label className='mwsbody'>Top Category</label>
                <select name="active" className='labelbox'>
                    <option value="selectall">Select All</option>
                    <option value="Search">search</option>
                </select>
                <button className='search'>Submit</button>
            </form>
        </div>
    )
}
export default Managewebsite;