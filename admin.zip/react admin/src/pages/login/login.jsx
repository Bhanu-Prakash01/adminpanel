import './login.css'
import {useHistory,BrowserRouter as Router,Link,Route,Switch} from 'react-router-dom';
import React,{useState} from 'react'
const Login=()=>{
    let history=useHistory();

    return(
        <div className='logcon'>
            <div className='loginbox'>
                <h1 className='sign'>Sign In</h1>
                <form >
                    <input type='text' className='usrid' placeholder='email id ....'/>
                    <input type='password'  classname='pasw' placeholder='password'/>
                    <button onClick={()=>history.push('/')}>Sign In</button>
                </form>
            </div>
        </div>
    );
}
export default Login;