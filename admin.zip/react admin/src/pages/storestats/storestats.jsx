import './storestats.css'
function Storestats(){
    return(
        <div className='storestastbody'>
            <form className='statsfrom'>
                <label className='mwstitle'> Get Stats</label>
                <label className='statslabelfirst'>Please Select Store</label>
                <select name="storeselection" className='statslabel'>
                    <option value="Ongole">Ongole</option>
                    <option value="Nellore">Nellore</option>
                    <option value="Vijayawada">Vijayawada</option>
                    <option value="Goa">Goa</option>
                    <option value="open">Open</option>
                    <option value="Tirupathi">Tirupathi</option>
                </select>
                <div className='inforn'>
                    <label className='fromstatsdate'>From Date</label>
                    <input type='date'className='rightlinp'></input>
                    <label className='fromstatsdate'>From Date</label>
                    <input type='date'className='rightlinp'></input>
                </div>
                <button className='status'>Get Stats</button>
            </form>
        </div>
    )
}
export default Storestats;