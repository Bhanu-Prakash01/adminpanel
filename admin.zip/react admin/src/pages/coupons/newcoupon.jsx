
export default function Newcoupon() {
    return (
      <div className="newProduct">
        <h1 className="addProductTitle">New City</h1>
        <form className="addProductForm">
          
          <div className="addProductItem">
            <label>Coupen code</label>
            <input type="text" placeholder="Coupen code" />
          </div>
          <div className="addProductItem">
            <label>Discount</label>
            <input type="text" placeholder="Coupen code" />
          </div>
          <div className="addProductItem">
            <label>Expire</label>
            <input type="date" />
          </div>
          <div className="addProductItem">
            <label>description</label>
            <input type="text" placeholder="description" />
          </div>
          <div className="addProductItem">
            <label>Active</label>
            <select name="active" id="active">
              <option value="yes">Yes</option>
              <option value="no">No</option>
            </select>
          </div>
          <button className="addProductButton">Create</button>
        </form>
      </div>
    );
  }
  