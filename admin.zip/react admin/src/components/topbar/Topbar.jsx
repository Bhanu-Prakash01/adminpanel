import React,{useState}from "react";
import "./topbar.css";
import Sidebar from '../sidebar/Sidebar'
import IconButton from '@material-ui/core/IconButton';
import {  Language } from "@material-ui/icons";
import {useHistory} from 'react-router-dom'
import MenuIcon from '@material-ui/icons/Menu';
export default function Topbar(props) {
  const history=useHistory(); 
  const popups=()=>{
    alert('logout successfully')
    history.push('/login')
  }
  return (
    <div className="topbar">
      <div className="topbarWrapper">
        <div className="topLeft">
          <span className="logo">Glossier</span>
          <span className="menu">
            <IconButton color="primary" onClick={()=><Sidebar open={true}/>} component="span">
              <MenuIcon />
            </IconButton>
          </span>
        </div>
        <div className="topRight">
          <div className="topbarIconContainer">
            <Language />
            <span className="topIconBadge">2</span>
          </div>
          <button className="topbarbuttonIconContainer" >
            log out
          </button>
          <img src="https://images.pexels.com/photos/1526814/pexels-photo-1526814.jpeg?auto=compress&cs=tinysrgb&dpr=2&w=500" alt="" className="topAvatar" />
        </div>
      </div>
    </div>
  );
}
