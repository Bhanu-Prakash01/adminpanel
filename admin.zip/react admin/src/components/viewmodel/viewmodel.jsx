import Modal from 'react-modal'
function Viewmodel(){
  return(
    <Modal isOpen={true}>
      <h1>bds</h1>
      <p>kggdhb</p>
    </Modal>
  )
}
export default Viewmodel;