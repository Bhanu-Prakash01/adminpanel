import "./featuredInfo.css";
import { ArrowDownward, ArrowUpward } from "@material-ui/icons";
import StoreTwoToneIcon from '@material-ui/icons/StoreTwoTone';
export default function FeaturedInfo() {
  return (
    <div className="featured">
      <div className="featuredItem">
        <span className="featuredTitle">Orders</span>
        <div className="featuredMoneyContainer">
          <span className="featuredMoney">56</span>  
        </div>
      </div>
      <div className="featuredItem">
        <span className="featuredTitle">Users</span>
        <div className="featuredMoneyContainer">
          <span className="featuredMoney">685</span>
        </div>
        
      </div>
      <div className="featuredItem">
        <span className="featuredTitle">Stores</span>
        <div className="featuredMoneyContainer">
          <span className="featuredMoney">25</span>
          
        </div>
         
      </div>
    </div>
  );
}
