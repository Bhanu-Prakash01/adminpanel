import "./sidebar.css";
import ChatIcon from '@material-ui/icons/Chat';
import LockOpenIcon from '@material-ui/icons/LockOpen';
import SupervisorAccountIcon from '@material-ui/icons/SupervisorAccount';
import EqualizerIcon from '@material-ui/icons/Equalizer';
import LocalOfferIcon from '@material-ui/icons/LocalOffer';
import DateRangeIcon from '@material-ui/icons/DateRange';
import MailOutlineIcon from '@material-ui/icons/MailOutline';
// i/mport LanguageIcon from '@material-ui/icons/Language';
import {useHistory} from 'react-router-dom'
import NotificationsActiveIcon from '@material-ui/icons/NotificationsActive';
import React,{useState} from 'react'
import AnnouncementIcon from '@material-ui/icons/Announcement';
import {
  LineStyle,
  Timeline,
  TrendingUp,
  Language,
  PermIdentity,
  Storefront,
  AttachMoney,
  BarChart,
  MailOutline,
  LocationCityTwoTone,
  DynamicFeed,
  ChatBubbleOutline,
  WorkOutline,
  Report,
} from "@material-ui/icons";
import { Link } from "react-router-dom";

export default function Sidebar({open}) {
  const history=useHistory();
  
  return (
    <div className={true?"sidebaractive":"sidebar"}>
      <div className="sidebarWrapper">
        <div className="sidebarMenu">
          <h3 className="sidebarTitle">Main</h3>
          <ul className="sidebarList">
            <Link to="/" className="link">
            <li className="sidebarListItem active">
              <LineStyle className="sidebarIcon" />
              Dashboard
            </li>
            </Link>
          </ul>
          <ul className="sidebarList">
            <Link to="/users" className="link">
              <li className="sidebarListItem">
                <PermIdentity className="sidebarIcon" />
                Users
              </li>
            </Link>
            <Link to="/products" className="link">
              <li className="sidebarListItem">
                <Storefront className="sidebarIcon" />
                Products
              </li>
            </Link>
            <Link to="/stores" className="link">
              <li className="sidebarListItem">
                <Storefront className="sidebarIcon" />
                  stores
              </li>
            </Link>
            <Link to="/cities" className="link">
              <li className="sidebarListItem">
                <LocationCityTwoTone className="sidebarIcon" />
                  Cites
              </li>
            </Link>
            <Link to='/transations' className="link">
              <li className="sidebarListItem">
                <AttachMoney className="sidebarIcon" />
                Transactions
              </li>
            </Link>
          </ul>
        </div>
        <div className="sidebarMenu">
          <h3 className="sidebarTitle">Manage</h3>
          <ul className="sidebarList">
            <li className="sidebarListItem">
              <Link to='/languages' className="link">
                <Language className="sidebarIcon" />
                  Languages
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/notification' className="link">
                <NotificationsActiveIcon className="sidebarIcon" />
                  Notification
              </Link>  
            </li>
            {/* <li className="sidebarListItem">
              <Link to='/manageapp' className="link">
                <NotificationsActiveIcon className="sidebarIcon" />
                  Manage App
              </Link>  
            </li> */}
            <li className="sidebarListItem">
              <Link to='/coupons' className="link">
                <LocalOfferIcon  className="sidebarIcon" />
                 Coupons 
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/coupons' className="link">
                <ChatIcon   className="sidebarIcon" />
                 Contact
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/storestats' className="link">
                <EqualizerIcon  className="sidebarIcon" />
                 Store stats 
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/admin' className="link">
                <LockOpenIcon  className="sidebarIcon" />
                 Manage App
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/sendmail' className="link">
                <MailOutlineIcon  className="sidebarIcon" />
                 Send Emails
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/coupons' className="link">
                <DateRangeIcon   className="sidebarIcon" />
                 General
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/managepopup' className="link">
                <AnnouncementIcon  className="sidebarIcon" />
                  Manage Popup
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/manageapp' className="link">
                <SupervisorAccountIcon  className="sidebarIcon" />
                  Administrator
              </Link>  
            </li>
            <li className="sidebarListItem">
              <Link to='/managewebsite' className="link">
                <Language  className="sidebarIcon" />
                  Manage Websites
              </Link>  
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}
