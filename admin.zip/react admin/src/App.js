import Sidebar from "./components/sidebar/Sidebar";
import Topbar from "./components/topbar/Topbar";
import "./App.css";
import Home from "./pages/home/Home";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import UserList from "./pages/userList/UserList";
import User from "./pages/user/User";
import NewUser from "./pages/newUser/NewUser";
import ProductList from "./pages/productList/ProductList";
import Product from "./pages/product/Product";
import Storeslist from './pages/storeslist/storeslist'
import Stores from './pages/stores/stores';
import NewProduct from "./pages/newProduct/NewProduct";
import Newstore from "./pages/newstore/newstore";
import Cities from "./pages/cites/cites";
import City from "./pages/city/city";
import Newcity from "./pages/newcity/newcity";
import Transaction from "./pages/newtransactions/newtransactions"
import Transactions from "./pages/transactions/transactions";
import Language from "./pages/language/language"
import Newlanguage from "./pages/language/newlanguage"
import Editlanguage from "./pages/language/editlanguage"
import Notification from './pages/notification/notification';
import Coupons from './pages/coupons/coupons';
import Sendmail from './pages/sendmail/sendmail'
import Newcoupon from './pages/coupons/newcoupon';
import Editcoupon from './pages/coupons/editcoupon'
import Managepopup from './pages/managepopup/managepopup';
import Storestats from './pages/storestats/storestats';
import Managewebsite from './pages/managewebsite/managewebsite';
import Manageapp from './pages/admin/admin';
import Editmanageapp from './pages/admin/editadmin';
import Newmanageapp from './pages/admin/newadmin';
import Admin from './pages/manageapp/manageapp';
import Login from './pages/login/login'
import Detailview from './pages/detailview/detailview'
function App() {
  return (
    <Router>
      <Topbar />
      <div className="container">
        <Sidebar />
        <Switch>
          <Route exact path="/login">
            <Login />
          </Route>
          <Route exact path="/">
            <Home />
          </Route>
          <Route exact path="/stores">
            <Storeslist />
          </Route>
          <Route exact path="/store/:storeId">
            <Stores />
          </Route>
          <Route path="/newstore">
            <Newstore />
          </Route>
          <Route path="/users">
            <UserList />
          </Route>
          <Route path="/user/:userId">
            <User />
          </Route>
          <Route path="/newUser">
            <NewUser />
          </Route>
          <Route path="/products">
            <ProductList />
          </Route>
          <Route path="/product/:productId">
            <Product />
          </Route>
          <Route path="/newproduct">
            <NewProduct />
          </Route>
          <Route path='/cities'>
            <Cities/>
          </Route>
          <Route path='/city/:cityId'>
            <City/>
          </Route>
          <Route path='/newcity'>
            <Newcity/>
          </Route>
          <Route path='/transations'>
            <Transactions/>
          </Route>
          <Route path='/transation/:transactionId'>
            <Transaction/>
          </Route>
          <Route path='/languages'>
            <Language/>
          </Route>
          <Route exact path='/language/:idlanguage'>
            <Editlanguage/>
          </Route>
          <Route exact path='/newlanguage'>
            <Newlanguage/>
          </Route>
          <Route exact path='/notification'>
            <Notification/>
          </Route>
          <Route exact path='/coupons'>
            <Coupons/>
          </Route>
          <Route exact path='/newcoupons'>
            <Newcoupon/>
          </Route>
          <Route exact path='/coupon/:Idcoupon'>
            <Editcoupon/>
          </Route>
          <Route exact path='/managewebsite'>
            <Managewebsite/>
          </Route>
          <Route exact path='/managepopup'>
            <Managepopup/>
          </Route>
          <Route exact path='/sendmail'>
            <Sendmail/>
          </Route>
          <Route exact path='/storestats'>
            <Storestats/>
          </Route>
          <Route exact path='/manageapp'>
            <Manageapp/>
          </Route>
          <Route exact path='/manageapp/:id'>
            <Editmanageapp/>
          </Route>
          <Route exact path='/newmanageapp'>
            <Newmanageapp/>
          </Route>
          <Route exact path='/admin'>
            <Admin/>
          </Route>
          <Route exact path='/detailview'>
            <Detailview/>
          </Route>
          <Route exact path='/detailview/:detailviewid'>
            <Detailview/>
          </Route>
        </Switch>
      </div>
    </Router>
  );
}

export default App;
